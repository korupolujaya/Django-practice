from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(MovieName)
admin.site.register(Actor)
admin.site.register(Director)
